const API_TOKEN = "YOU_API_TOKEN"; // Api token trên web OMOcaptcha.com
const DELAY_CLICK = 3000; // Khoảng cách click (mili giây)
const LOOP = true; // Để true sẽ giải đến khi thành công