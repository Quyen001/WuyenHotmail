const API_TOKEN = "YOU_API_TOKEN";
const DELAY_CLICK = 3000;
const LOOP = true;